<?php


try {

    $conn = new mysqli("172.26.0.2", "root", "123456", "bdd_hoteleria");

	if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    
} catch (Exception $e) {

    echo "Error de conexión: " . $e->getMessage();
}

?>

