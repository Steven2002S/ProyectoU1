<?php

require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recoger valores del formulario
    $cedula = $_POST["cedula"];
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $direccion = $_POST["direccion"];
    $ciudad = $_POST["ciudad"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];

    $id_habitacion = $_POST['id_habitacion'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];
    $precio = $_POST['precio'];

    $id_hotel = $_POST['id_hotel'];


    // Verificar si el cliente ya existe
    $sqlVerificarCliente = "SELECT * FROM cliente WHERE cedula = '$cedula'";
    $resultadoVerificacion = mysqli_query($conn, $sqlVerificarCliente);

    if (mysqli_num_rows($resultadoVerificacion) > 0) {
        $fila = mysqli_fetch_assoc($resultadoVerificacion);
        $idCliente = $fila["id_cliente"];

        $sql = "CALL registrar_reservacion(?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iissss", $idCliente, $id_habitacion, $fecha_inicio, $fecha_fin, $fecha_inicio, $precio);
        $stmt->execute();

    } else {
        $sqlCliente = "INSERT INTO cliente (cedula, nombre, apellido, direccion, id_ciudad, telefono, correo_electronico)
                VALUES ('$cedula', '$nombre', '$apellido', '$direccion', '$ciudad', '$telefono', '$email')";

        if (mysqli_query($conn, $sqlCliente)) {
            $idClienteNuevo = $conn->insert_id;

            $sql = "CALL registrar_reservacion(?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iissss", $idClienteNuevo, $id_habitacion, $fecha_inicio, $fecha_fin, $fecha_inicio, $precio);
            $stmt->execute();

            header('Location: /main/sistema/app/dashboard/principal.php?id_hotel=' . $id_hotel);
        } else {
            echo "Error al registrar el cliente: " . mysqli_error($conexion);
        }
   }

   // Cerrar la conexión a la base de datos
   mysqli_close($conn);
   
   /* if ($conn->query($sqlCliente)) {
        $clienteId = $conn->insert_id;  // Obtener el ID del hotel recién insertado
        //print($hotelId);
        // Procesar tipos de habitación
        if (is_array($habitacionesView)) {
            // Iterar sobre el array de habitaciones
            foreach ($habitacionesView as $habitacion) {
                // Acceder a las propiedades individuales de cada habitación
                $tipo = $habitacion['tipo'];
                $descripcion = $habitacion['descripcion'];
                $capacidad = $habitacion['capacidad'];
                $precio = $habitacion['precio'];

                $sqlTipoHabitacion = "INSERT INTO tipo_habitacion (nombre, descripcion, capacidad, precio)
                VALUES ('$tipo', '$descripcion', '$capacidad', '$precio')";
    
                // Acceder al array de habitaciones dentro de cada habitación
                if ($conn->query($sqlTipoHabitacion) === TRUE) {
                    $tipoHabitacionId = $conn->insert_id;  // Obtener el ID del tipo de habitación recién insertado
                    $habitaciones = $habitacion['habitaciones'];
        
                    // Iterar sobre el array de habitaciones
                    foreach ($habitaciones as $habitacionIndividual) {
                        $sqlHabitacion = "INSERT INTO habitacion (id_tipo_habitacion, id_hotel, numero, disponibilidad)
                            VALUES ('$tipoHabitacionId', '$hotelId', '$habitacionIndividual', 1)";
                        $conn->query($sqlHabitacion);
                    }
                }
            }
        }
        header('Location: /sistema/principal.php?id_hotel=' . $hotelId);
        //echo "Registro exitoso";
    } else {
        echo "Error: " . $sqlHotel . "<br>" . $conn->error;
    }

    // Cerrar la conexión
    $conn->close();

    */
}
?>