<?php

require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger valores del formulario
    $nombre = $_POST["nombre"];
    $direccion = $_POST["direccion"];
    $email = $_POST["email"];
    $pais = $_POST["pais"];
    $ciudad = $_POST["ciudad"];
    $telefono = $_POST["telefono"];

    $habitacionesView = json_decode($_POST['habitacionesView'], true);

    // Insertar datos en la tabla Hotel
    $sqlHotel = "INSERT INTO hotel (nombre, direccion, id_ciudad, telefono, correo_electronico) 
                 VALUES ('$nombre', '$direccion', '$ciudad', '$telefono', '$email')";

    if ($conn->query($sqlHotel)) {
        $hotelId = $conn->insert_id;  // Obtener el ID del hotel recién insertado
        //print($hotelId);
        // Procesar tipos de habitación
        if (is_array($habitacionesView)) {
            // Iterar sobre el array de habitaciones
            foreach ($habitacionesView as $habitacion) {
                // Acceder a las propiedades individuales de cada habitación
                $tipo = $habitacion['tipo'];
                $descripcion = $habitacion['descripcion'];
                $capacidad = $habitacion['capacidad'];
                $precio = $habitacion['precio'];

                $sqlTipoHabitacion = "INSERT INTO tipo_habitacion (nombre, descripcion, capacidad, precio)
                VALUES ('$tipo', '$descripcion', '$capacidad', '$precio')";
    
                // Acceder al array de habitaciones dentro de cada habitación
                if ($conn->query($sqlTipoHabitacion) === TRUE) {
                    $tipoHabitacionId = $conn->insert_id;  // Obtener el ID del tipo de habitación recién insertado
                    $habitaciones = $habitacion['habitaciones'];
        
                    // Iterar sobre el array de habitaciones
                    foreach ($habitaciones as $habitacionIndividual) {
                        $sqlHabitacion = "INSERT INTO habitacion (id_tipo_habitacion, id_hotel, numero, disponibilidad)
                            VALUES ('$tipoHabitacionId', '$hotelId', '$habitacionIndividual', 1)";
                        $conn->query($sqlHabitacion);
                    }
                }
            }
        }
        header('Location: /main/sistema/app/dashboard/principal.php?id_hotel=' . $hotelId);
        //echo "Registro exitoso";
    } else {
        echo "Error: " . $sqlHotel . "<br>" . $conn->error;
    }

    // Cerrar la conexión
    $conn->close();
}
?>