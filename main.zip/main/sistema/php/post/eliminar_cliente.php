<?php

require_once '../conexion/conexion.php';

 
    if(isset($_GET['id_cliente']) && !empty(trim($_GET['id_cliente']))){

        $query = "DELETE FROM cliente WHERE id_cliente = ?";

        if($stmt = $conn->prepare($query)){
            $stmt->bind_param('i',$_GET['id_cliente']);
            if($stmt->execute()){
                header("location: /main/sistema/app/vistas/vista_cliente.php");
                exit();
            }
        }
        $stmt ->close();
        $conn ->close();
    }


?>