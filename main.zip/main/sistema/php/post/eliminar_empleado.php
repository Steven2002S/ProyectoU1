<?php

require_once '../conexion/conexion.php';

 
    if(isset($_GET['id_empleado']) && !empty(trim($_GET['id_empleado']))){

        $query = "DELETE FROM empleado WHERE id_empleado = ?";

        if($stmt = $conn->prepare($query)){
            $stmt->bind_param('i',$_GET['id_empleado']);
            if($stmt->execute()){
                header("location: /main/sistema/app/vistas/vista_empleado.php");
                exit();
            }
        }
        $stmt ->close();
        $conn ->close();
    }


?>