<?php

require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger valores del formulario

    $id_empleado = $_POST["id_empleado_editar"];
    $cargo = $_POST["cargo_editar"];
    $nombre = $_POST["nombre_editar"];
    $apellido = $_POST["apellido_editar"];
    $fecha = $_POST["fecha_editar"];
    $salario = $_POST["salario_editar"];

    $id_hotel = $_POST['id_hotel'];

    // Insertar datos en la tabla Hotel
    $sqlEmpleado = "UPDATE empleado SET
        id_cargo = '$cargo',
        nombre = '$nombre',
        apellido = '$apellido',
        fecha_contratacion = '$fecha',
        salario = '$salario'
        WHERE id_empleado = '$id_empleado'";

    if ($conn->query($sqlEmpleado)) {
        $hotelId = $conn->insert_id;  // Obtener el ID del hotel recién insertado

        header('Location: /main/sistema/app/vistas/vista_empleado.php?id_hotel='.$id_hotel.'');
        //echo "Registro exitoso";
    } else {
        echo "Error: " . $sqlEmpleado . "<br>" . $conn->error;
    }

    // Cerrar la conexión
    $conn->close();
}
?>