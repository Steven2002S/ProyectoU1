<?php

require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger valores del formulario

    $cargo = $_POST["cargo"];
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $fecha = $_POST["fecha"];
    $salario = $_POST["salario"];

    $id_hotel = $_POST['id_hotel'];


    // Insertar datos en la tabla Hotel
    $sqlEmpleado = "INSERT INTO empleado (id_cargo, id_hotel, nombre, apellido, fecha_contratacion, salario)
                 VALUES ('$cargo', '$id_hotel', '$nombre', '$apellido', '$fecha', '$salario')";

    if ($conn->query($sqlEmpleado)) {

        header('Location: /main/sistema/app/vistas/vista_empleado.php?id_hotel='.$id_hotel.'');
        //echo "Registro exitoso";
    } else {
        echo "Error: " . $sqlEmpleado . "<br>" . $conn->error;
    }

    // Cerrar la conexión
    $conn->close();
}
?>