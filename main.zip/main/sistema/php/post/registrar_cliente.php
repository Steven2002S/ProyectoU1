<?php

require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger valores del formulario

    $cedula = $_POST["cedula"];
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $direccion = $_POST["direccion"];
    $ciudad = $_POST["ciudad"];
    $telefono = $_POST["telefono"];
    $email = $_POST["email"];

    $id_hotel = $_POST['id_hotel'];


    // Insertar datos en la tabla Hotel
    $sqlCliente = "INSERT INTO cliente (cedula, nombre, apellido, direccion, id_ciudad, telefono, correo_electronico)
                VALUES ('$cedula', '$nombre', '$apellido', '$direccion', '$ciudad', '$telefono', '$email')";

    if ($conn->query($sqlCliente)) {

        header('Location: /main/sistema/app/vistas/vista_cliente.php?id_hotel='.$id_hotel.'');
        //echo "Registro exitoso";
    } else {
        echo "Error: " . $sqlCliente . "<br>" . $conn->error;
    }

    // Cerrar la conexión
    $conn->close();
}
?>