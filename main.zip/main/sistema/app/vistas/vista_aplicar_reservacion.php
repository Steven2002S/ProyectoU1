<?php
	/*session_start();
	require 'conexion.php';
	
	if(!isset($_SESSION['id'])){
		header("Location: index.php");
	}
	
	$id = $_SESSION['id'];
	$tipo_usuario = $_SESSION['tipo_usuario'];
	
	if($tipo_usuario == 1){
		$where = "";
		} else if($tipo_usuario == 2){
		$where = "WHERE id=$id";
	}
	
	$sql = "SELECT * FROM usuarios $where";
	$resultado = $mysqli->query($sql);
	*/

	require_once  ('../.././php/get/datos_hotel.php');
	require_once  ('../.././php/conexion/conexion.php');
	require_once  ('../.././php/config/config.php');

	if($_GET['id_hotel']){

		$id_hotel = $_GET['id_hotel'];
        $id_habitacion = $_GET['id_habitacion'];

		// Obtener información del hotel
		$hotel_info = getHotelInfo($conn, $id_hotel);

		// Verificar si se encontraron resultados
		if ($hotel_info) {
			// Guardar los datos en variables
			//$hotel_id = $hotel_info["id_hotel"];
			$nombre_hotel = $hotel_info["nombre_hotel"];
			$total_habitaciones = $hotel_info["total_habitaciones"];
			$habitaciones_disponibles = $hotel_info["total_habitaciones_disponibles"];
			$habitaciones_ocupadas = $hotel_info["total_habitaciones_ocupadas"];
			$reservaciones_hoy = $hotel_info["reservaciones_hoy"];
		} else {
			$hotel_id = "N/D";
			$nombre_hotel = "N/D";
			$total_habitaciones = "N/D";
			$habitaciones_disponibles = "N/D";
			$habitaciones_ocupadas = "N/D";
			$reservaciones_hoy = "N/D";
		}

	
	    $sql_vh = "SELECT * FROM vista_habitaciones WHERE  id_habitacion = $id_habitacion";
    	$resultvh = $conn->query($sql_vh);

    if ($resultvh->num_rows > 0) {
        // Utilizar fetch_assoc para obtener la fila como un array asociativo
        $habitacion_info = $resultvh->fetch_assoc();

        // Guardar los datos en variables
        $id_habitacion = $habitacion_info["id_habitacion"];
        $tipo_habitacion = $habitacion_info["tipo_habitacion"];
        $capacidad = $habitacion_info["capacidad"];
        $precio = $habitacion_info["precio"];
        $numero = $habitacion_info["numero"];
        $disponibilidad = $habitacion_info["disponibilidad"];
        $id_hotel = $habitacion_info["id_hotel"];
        $id_tipo_habitacion = $habitacion_info["id_tipo_habitacion"];
    }

	$sql_cuidades = "SELECT * FROM ciudad";
		$result = $conn->query($sql_cuidades);

		if ($result->num_rows > 0) {
			$ciudades = array();
			while ($row = $result->fetch_assoc()) {
				$ciudades[] = $row;
			}
		}


	}



?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<meta name="description" content="" />
	<meta name="author" content="" />
	<title>Tables - SB Admin</title>
	<link href="../.././css/styles.css" rel="stylesheet" />
	<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet"
		crossorigin="anonymous" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js"
		crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
	<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
		<a class="navbar-brand" href="../dashboard/principal.php?id_hotel=<?php echo $id_hotel; ?>">
			<?php echo $nombre_hotel ; ?>
		</a>
		<button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i
				class="fas fa-bars"></i></button><!-- Navbar Search-->
		<form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
			<div class="input-group">
				<input class="form-control" type="text" placeholder="Search for..." aria-label="Search"
					aria-describedby="basic-addon2" />
				<div class="input-group-append">
					<button class="btn btn-primary" type="button"><i class="fas fa-search"></i></button>
				</div>
			</div>
		</form>
		<!-- Navbar-->
		<ul class="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $nombre_hotel." - Usuario "; ?><i class="fas fa-user fa-fw"></i></a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="#">Configuración</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="../.././php/config/logout.php">Salir</a>
					</div>
				</li>
			</ul>
	</nav>
	<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="../dashboard/principal.php?id_hotel=<?php echo $id_hotel; ?>"
							><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard</a
							>
							
							<?php if(true) { ?>
								
								<div class="sb-sidenav-menu-heading">Interface</div>
								<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts"
								><div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
									Layouts
									<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
									></a>
									<div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
										<nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="layout-static.html">Static Navigation</a><a class="nav-link" href="layout-sidenav-light.html">Light Sidenav</a></nav>
									</div>
									<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages"
									><div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
										Pages
										<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
										></a>
										<div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
											<nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
												<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth"
												>Authentication
													<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
													></a>
													<div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
														<nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="login.html">Login</a><a class="nav-link" href="register.html">Register</a><a class="nav-link" href="password.html">Forgot Password</a></nav>
													</div>
													<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError"
													>Error
														<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div
														></a>
														<div class="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
															<nav class="sb-sidenav-menu-nested nav"><a class="nav-link" href="401.html">401 Page</a><a class="nav-link" href="404.html">404 Page</a><a class="nav-link" href="500.html">500 Page</a></nav>
														</div>
											</nav>
										</div>
										
							<?php } ?>
							
							
							<div class="sb-sidenav-menu-heading">Addons</div>
							<a class="nav-link" href="vista_cliente.php?id_hotel=<?php echo $id_hotel; ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>Clientes</a>
                            <a class="nav-link" href="vista_empleado.php?id_hotel=<?php echo $id_hotel; ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>Empleados</a>
							
							</div>
					</div>

				</nav>
			</div>
		<div id="layoutSidenav_content">
			<main>
				<div class="container-fluid">
					<h1 class="mt-4">Registro de reservación</h1>
					<ol class="breadcrumb mb-4">
						<li class="breadcrumb-item"><a href="../dashboard/principal.php?id_hotel=<?php echo $id_hotel; ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="vista_hab_disponibles.php?id_hotel=<?php echo $id_hotel; ?>">Hab. disponibles</a></li>
						<li class="breadcrumb-item active">Reservación</li>
					</ol>
					<form action="../.././php/post/registrar_reservacion.php" method="post" id ="form">
					<div class="card mb-4" id="form-registrar">
						<div class="card-header"><i class="fas fa-table mr-1"></i>  Datos de la habitación</div>
						<div class="card-body">
							
								<div class="row">
									<div class="col form-group">
										<label for="nombre">Número de habitación</label>
										<input type="text" id="numero_hab" name="numero_hab" class="form-control" value="<?php echo $numero; ?>" disabled>
										<input type="hidden" id="id_habitacion" name="id_habitacion" value="<?php echo $id_habitacion; ?>">
									</div>
									<div class="col form-group">
										<label for="correo">Capacidad:</label>
										<input type="text" id="capacidad" name="capacidad" class="form-control" value="<?php echo $capacidad; ?>" disabled>
									</div>
                                    <div class="col form-group">
										<label for="nombre">Tipo de habitación:</label>
										<input type="text" id="tipo_hab" name="tipo_hab" class="form-control" value="<?php echo $tipo_habitacion; ?>" disabled>
									</div>
								</div>
								<div class="row">
                                    <div class="col form-group">
										<label for="correo">Fecha incio:</label>
										<input type="date" id="fecha_inicio" name="fecha_inicio" class="form-control"  >
									</div>
                                    <div class="col form-group">
										<label for="correo">Fecha fin:</label>
										<input type="date" id="fecha_fin" name="fecha_fin" class="form-control" required>
									</div>
                                    <div class="col form-group">
										<label for="precio"><b>Precio:</b></label>
										<input type="text" id="precio" name="precio" class="form-control" value="<?php echo $precio; ?>" disabled>
									</div>
								</div>
								<input type="hidden" name="id_hotel" value="<?php echo $id_hotel; ?>">
						</div>
					</div>
					<!-- Formulario de edición (inicialmente oculto) -->
					<div class="card mb-4" id="form-editar">
						<div class="card-header"><i class="fas fa-table mr-1"></i>Datos del cliente</div>
						<div class="card-body">
							<div class="row">
								<div class="col-8 form-group">
									<label for="cedula">Búsqueda por cédula:</label>
									<input type="text" id="cedula" name="cedula" class="form-control">
								</div>
								<div>
									<button type="submit" class="btn btn-primary">Buscar</button>
								</div>
							</div>
							<div class="row">
								<div class="col form-group">
									<label for="cedula">Cédula:</label>
									<input type="number" id="cedula" name="cedula" class="form-control" required>
								</div>
								<div class="col form-group">
									<label for="nombe">Nombre:</label>
									<input type="text" id="nombre" name="nombre" class="form-control" required>
								</div>
								<div class="col form-group">
									<label for="apellido">Apellido:</label>
									<input type="text" id="apellido" name="apellido" class="form-control" required>
								</div>
							</div>
							<div class="row">
								<div class="col form-group">
									<label for="direccion">Dirección:</label>
									<input type="text" id="direccion" name="direccion" class="form-control" required>
								</div>
								<div class="col form-group">
									<label for="ciudad">Ciudad:</label>
									<select name="ciudad" id="ciudad" class="form-control">
										<option value="">--- Seleccione una ciudad ---</option>
										<?php
											foreach ($ciudades as $ciudad) {
												echo "<option value='{$ciudad['id_ciudad']}'>{$ciudad['nombre']}</option>";
											}
											?>
									</select>
								</div>
							</div>
							<div class="row">
								<div class="col form-group">
									<label for="telefono">Teléfono:</label>
									<input type="number" id="telefono" name="telefono" class="form-control" required>
								</div>
								<div class="col form-group">
									<label for="email">Correo eléctronico:</label>
									<input type="email" id="email" name="email" class="form-control" required>
								</div>
							</div>
							<input type="hidden" id="id_empleado_editar" name="id_empleado_editar">
							<button type="submit" class="btn btn-primary btn-realizar-compra">REALIZAR PAGO</button>
						</div>
					</div>
				</form>
			</main>
			<footer class="py-4 bg-light mt-auto">
				<div class="container-fluid">
					<div class="d-flex align-items-center justify-content-between small">
						<div class="text-muted">Copyright &copy; Grupo 6
							<?php echo date('Y'); ?>
						</div>
						<div>
							<a href="#">Privacy Policy</a>
							&middot;
							<a href="#">Terms &amp; Conditions</a>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"
		crossorigin="anonymous"></script>
	<script src="../.././js/scripts.js"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
	<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
	<script src="assets/demo/datatables-demo.js"></script>
	<script>
    $(document).ready(function() {
        const ahora = new Date();

        // Obtener zona horaria offset del usuario 
        const timezoneOffset = ahora.getTimezoneOffset();

        // Ajustar fecha/hora según la zona horaria  
        ahora.setMinutes(ahora.getMinutes() - timezoneOffset);

        // Formatear en ISO 
        const fechaActual = ahora.toISOString().split('T')[0];

        // Insertar fecha de inicio en el elemento correspondiente
        document.getElementById("fecha_inicio").value = fechaActual;

        // Calcular fecha de fin con un día de diferencia
        const fechaFin = new Date(ahora);
        fechaFin.setDate(ahora.getDate() + 1);

        // Formatear la fecha de fin en ISO y asignarla al campo correspondiente
        const fechaFinISO = fechaFin.toISOString().split('T')[0];
        document.getElementById("fecha_fin").value = fechaFinISO;

		   
		
		// Manejar clic en el botón de eliminar
		$(".btn-realizar-compra").click(function() {
			var boton = $(this);

			// Obtener el formulario
			var formulario = $("#form")[0];

			// Verificar si el formulario es válido
			if (!formulario.checkValidity()) {
				// Si el formulario no es válido, mostrar mensajes de validación y salir
				formulario.reportValidity();
				return;
			}

			// Preguntar si desea realizar la transacción
			if (!confirm("¿Está seguro que desea realizar la transacción?")) {
				return;
			}

			// Enviar solicitud AJAX para realizar la transacción
			$.ajax({
				url: "./php/post/registrar_reservacion.php",
				method: "POST",
				data: $("#miFormulario").serialize(), // Enviar datos del formulario
				success: function(response) {
					// Manejar la respuesta si es necesario
					console.log(response);
					// Recargar la página o realizar otras acciones según tus necesidades
					location.reload();
				},
				error: function(xhr, status, error) {
					// Manejar errores si es necesario
					console.error(error);
				}
			});
		});

    });
	</script>
</body>

</html>